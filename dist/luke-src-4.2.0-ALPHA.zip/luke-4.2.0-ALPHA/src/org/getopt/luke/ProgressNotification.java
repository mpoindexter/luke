package org.getopt.luke;

public class ProgressNotification {
  public int curValue = 0;
  public int minValue = 0;
  public int maxValue = 0;
  public boolean aborted = false;
  public String message = null;
}
